package com.example.profliecardappmine

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.profliecardappmine.ui.theme.ProflieCardAppmineTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProflieCardAppmineTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ProfileScreen()
                }
            }
        }
    }
}

@Composable
fun ProfileScreen() {

    val sections = listOf("My Bio", "Education", "Experience", "Skills", "PoR", "Extra Curricular")
    var selectedSection by remember { mutableStateOf("My Bio") }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text(
                text = ".portfolio",
                fontSize = 18.sp,
                fontWeight = FontWeight.W500,
                modifier = Modifier.padding(8.dp)
            )
        }
        Box(
            modifier = Modifier
                .height(200.dp)
                .padding(horizontal = 2.dp)
                .clip(shape = RoundedCornerShape(8))
        ) {
            Image(
                painter = painterResource(id = R.drawable.background),
                contentDescription = "background",
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
                    .height(100.dp)
                    .clip(shape = RoundedCornerShape(8)),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .padding(start=20.dp, top= 100.dp)
                    .size(100.dp)
                    .align(Alignment.BottomStart)
                    .clip(shape = CircleShape)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.face2), contentDescription = "face",
                    modifier = Modifier.clip(shape = CircleShape),
                    contentScale = ContentScale.Crop
                )

//                Box(modifier = Modifier
//                    .size(10.dp)
//                    .clip(CircleShape)
//                    .background(Color(0xFF2196F3))
//                    .border(4.dp, Color.White, CircleShape)
//                    .align(Alignment.BottomEnd)){
//
//                }
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            "Srushti Tambe", modifier = Modifier.padding(start = 16.dp),
            style = TextStyle(
                fontSize = 22.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.W600
            )
        )
        Text(
            "Android Developer", modifier = Modifier.padding(start = 16.dp),
            style = TextStyle(
                fontSize = 14.sp,
                color = Color.Gray,
                fontFamily = FontFamily.Serif
            )
        )
        Spacer(modifier = Modifier.height(12.dp))
        Box(modifier = Modifier
            .height(100.dp)
            .padding(2.dp)
            .clip(shape = RoundedCornerShape(8))){
            Column{
                Row(modifier = Modifier.padding(start=16.dp, bottom = 8.dp) ){
                    Icon(painter = painterResource(id = R.drawable.phone), contentDescription = "phone",
                        modifier = Modifier.size(20.dp))
                    Text(text = "+919988877766", modifier = Modifier.padding(start=40.dp), fontFamily = FontFamily.Serif, fontWeight = FontWeight.Light, fontSize = 15.sp)
                }
                Row(modifier = Modifier.padding(start=16.dp, bottom = 8.dp) ){
                    Icon(painter = painterResource(id = R.drawable.email), contentDescription = "email",
                        modifier = Modifier.size(20.dp))
                    Text(text = "srushti.tambe@aurionpro.com", modifier = Modifier.padding(start=40.dp), fontFamily = FontFamily.Serif, fontWeight = FontWeight.Light, fontSize = 15.sp)
                }
                Row(modifier = Modifier.padding(start=16.dp, bottom = 8.dp) ){
                    Icon(painter = painterResource(id = R.drawable.dept), contentDescription = "department",
                        modifier = Modifier.size(20.dp))
                    Text(text = "Transit", modifier = Modifier.padding(start=40.dp), fontFamily = FontFamily.Serif, fontWeight = FontWeight.Light, fontSize = 15.sp)
                }
            }
        }

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(sections) { section ->
                Text(
                    text = section,
                    modifier = Modifier
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .clickable {
                            selectedSection = section
                        },
                    fontSize = 20.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.W500,
                    color = if (section == selectedSection) Color.Black else Color.Gray
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Box(
            modifier = Modifier
                .fillMaxSize()
                .height(200.dp)
                .padding(8.dp)
                .background(color = Color(0xffA396D9), shape = RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn() {
                item {
                    when(selectedSection){
                        "My Bio"->{
                            MyBio()
                        }
                        "Education"->{
                            Education()
                        }
                        "Experience"->{
                            Experience()
                        }
                        "Skills"->{
                            Skills()
                        }
                        "PoR"->{
                            PoR()
                        }
                        "Extra Curricular"->{
                            ExtraCurricular()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MyBio(){
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "My Bio",
            color = Color.White,
            fontSize = 22.sp,
            fontStyle = FontStyle.Italic,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "Hey! I am Srushti Tambe, a Android Developer.\nI am a curious learner passionate about technology and problem-solving. Skilled in building user-friendly applications and exploring innovative solutions, I enjoy combining creativity with logic. With a collaborative mindset, I strive to grow continuously while contributing meaningfully to projects.",
            color = Color.White,
            fontSize = 18.sp,
            lineHeight = 30.sp,
            modifier = Modifier.padding(8.dp),
            fontFamily = FontFamily.Serif
        )
    }
}
@Composable
fun Education(){
    Column(horizontalAlignment = Alignment.CenterHorizontally){
        Text(
            text = "Education",
            color = Color.White,
            fontSize = 22.sp,
            fontStyle = FontStyle.Italic,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "• BE in Computer Engineering at SIES.",
            color = Color.White,
            fontSize = 18.sp,
            lineHeight = 30.sp,
            modifier = Modifier
                .padding(8.dp)
                .align(Alignment.Start),
            fontFamily = FontFamily.Serif
        )
        Text(text = "(2021-2025)",
            color = Color.White,
            fontSize = 16.sp,
            lineHeight = 30.sp,
            modifier = Modifier
                .padding(8.dp)
                .align(Alignment.End),
            fontFamily = FontFamily.Serif,
            fontStyle = FontStyle.Italic)
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "• Scored 91.6% in class 12th SSC board.",
            color = Color.White,
            fontSize = 18.sp,
            lineHeight = 30.sp,
            modifier = Modifier
                .padding(8.dp)
                .align(Alignment.Start),
            fontFamily = FontFamily.Serif
        )
        Text(text = "(2021)",
            color = Color.White,
            fontSize = 16.sp,
            lineHeight = 30.sp,
            modifier = Modifier
                .padding(8.dp)
                .align(Alignment.End),
            fontFamily = FontFamily.Serif,
            fontStyle = FontStyle.Italic)
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "• Scored 91.0% in class 10th CBSE board.",
            color = Color.White,
            fontSize = 18.sp,
            lineHeight = 30.sp,
            modifier = Modifier
                .padding(8.dp)
                .align(Alignment.Start),
            fontFamily = FontFamily.Serif
        )
        Text(text = "(2019)",
            color = Color.White,
            fontSize = 16.sp,
            lineHeight = 30.sp,
            modifier = Modifier
                .padding(8.dp)
                .align(Alignment.End),
            fontFamily = FontFamily.Serif,
            fontStyle = FontStyle.Italic)
    }
}

@Composable
fun Experience(){
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "Experience",
            color = Color.White,
            fontSize = 22.sp,
            fontStyle = FontStyle.Italic,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "Aurionpro| Android Developer              ",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.W600,
            modifier = Modifier
                .padding(8.dp)
                .align(Alignment.Start),
            fontFamily = FontFamily.Serif
        )
        Text(
            text = "• Developed and optimized Android applications using Kotlin and Java",
            color = Color.White,
            fontSize = 16.sp,
            modifier = Modifier.padding(8.dp),
            fontFamily = FontFamily.Serif
        )
        Text(
            text = "• Implemented UI with Jetpack Compose and Material Design components",
            color = Color.White,
            fontSize = 16.sp,
            modifier = Modifier.padding(8.dp),
            fontFamily = FontFamily.Serif
        )
        Text(
            text = "• Worked with REST APIs and integrated third-party libraries",
            color = Color.White,
            fontSize = 16.sp,
            modifier = Modifier.padding(8.dp),
            fontFamily = FontFamily.Serif
        )

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "EasyGoLife| Full Stack Developer",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.W600,
            modifier = Modifier
                .padding(8.dp)
                .align(Alignment.Start),
            fontFamily = FontFamily.Serif
        )
        Text(
            text = "•  Designed and developed a website for an organisation that manages NGOs in India focused on technology and IT fields",
            color = Color.White,
            fontSize = 16.sp,
            modifier = Modifier
                .padding(8.dp)
                .align(Alignment.Start),
            fontFamily = FontFamily.Serif
        )
        Text(
            text = "• Implemented UI with HTML, CSS, and JavaScript on the frontend, while using Node.js, Express.js and \n" +
                    "phpMyAdmin on the backend for server connection.",
            color = Color.White,
            fontSize = 16.sp,
            modifier = Modifier.padding(8.dp),
            fontFamily = FontFamily.Serif
        )
    }
}
@Composable
fun Skills(){

    Column(horizontalAlignment = Alignment.CenterHorizontally){
        Text(
            text = "Skills",
            color = Color.White,
            fontSize = 22.sp,
            fontStyle = FontStyle.Italic,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "Skilled in full-stack development (C/C++, HTML, CSS, JavaScript, Node.js, Express.js, Java, Python, MySQL) with strong expertise in Machine Learning, NLP, and Data Science, leveraging tools such as Tkinter, NumPy, Pandas, PyTorch, and OpenCV for advanced image processing solutions.",
            color = Color.White,
            fontSize = 18.sp,
            lineHeight = 30.sp,
            modifier = Modifier.padding(8.dp),
            fontFamily = FontFamily.Serif
        )
    }
}

@Composable
fun PoR(){

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "Position of Responsibility",
            color = Color.White,
            fontSize = 22.sp,
            fontStyle = FontStyle.Italic,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "Event Head| TML           (Feb 2023)",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.W600,
            modifier = Modifier
                .padding(8.dp)
                .align(Alignment.Start),
            fontFamily = FontFamily.Serif
        )
        Text(
            text = "• Served as an event head during the cultural fest of SIES GST",
            color = Color.White,
            fontSize = 16.sp,
            modifier = Modifier.padding(8.dp),
            fontFamily = FontFamily.Serif
        )
        Text(
            text = "• Contacted 15+ companies for sponsorship, and handled marketing and branding of the event",
            color = Color.White,
            fontSize = 16.sp,
            modifier = Modifier.padding(8.dp),
            fontFamily = FontFamily.Serif
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Core| TnP Cell              (2024-2025)",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.W600,
            modifier = Modifier
                .padding(8.dp)
                .align(Alignment.Start),
            fontFamily = FontFamily.Serif
        )
        Text(
            text = "• Acted as a point of contact for both company HRs and students.",
            color = Color.White,
            fontSize = 16.sp,
            modifier = Modifier.padding(8.dp),
            fontFamily = FontFamily.Serif
        )

    }
}

@Composable
fun ExtraCurricular(){
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "Extra Curricular",
            color = Color.White,
            fontSize = 22.sp,
            fontStyle = FontStyle.Italic,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "• Acted as a point of contact for both company HRs and students",
            color = Color.White,
            fontSize = 18.sp,
            modifier = Modifier.padding(8.dp),
            fontFamily = FontFamily.Serif
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "• Participated in bug-squash",
            color = Color.White,
            fontSize = 18.sp,
            modifier = Modifier
                .padding(8.dp)
                .align(Alignment.Start),
            fontFamily = FontFamily.Serif
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "• Secured first and second position in carrom competition during sports fest of SIES GST",
            color = Color.White,
            fontSize = 18.sp,
            modifier = Modifier
                .padding(8.dp)
                .align(Alignment.Start),
            fontFamily = FontFamily.Serif
        )

    }
}


@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    ProflieCardAppmineTheme {
        ProfileScreen()
    }
}